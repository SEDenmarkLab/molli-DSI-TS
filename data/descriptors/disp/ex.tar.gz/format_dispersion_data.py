import pandas as pd
import glob
import re
import numpy as np


counter = 0
for f in glob.glob("*_fragment_labels.csv"):
    df1 = pd.read_csv(f)
    np1 = df1.to_numpy()
    np1[0,2:] = np1[2,2:]
    df1=pd.DataFrame(np1)
    df1.to_csv(f"{f}_modded.csv", index=None)

df1 = pd.read_csv("all_dispersion_data.csv")
print(df1)
np1 = df1.to_numpy()

substrates = ['2a','2b', '2c', '2e', '2h','2j','2k', '2l', '2m', '2n']  
catalysts = {'ClC#CC3=CC=C_C_F__F_F_C=C3': '4s',
            'ClC#CC5=CC=C_OC_C=C5': '4x',
            'ClC#CC2=CC=CC=C2C_F__F_F_': '3d', 
            'ClC#CC1CCCCC1': '3k',
            'ClC#CC4=CC=C__N+___O-__=O_C=C4': '4w'
            }
TS_structs = ["S-ax-S", "S-ax-R", "R-ax-R", "R-ax-S"]
pattern = '|'.join(map(re.escape, substrates))
print(pattern)
regex = re.compile(pattern)

_tmp = []
_full = []
for i,row in enumerate(np1[:,2]):
    #if substrates[:] in row:
    #print(catalysts.keys())
    test = '|'.join(map(re.escape, catalysts.keys()))# for key in catalysts.keys())
    regex_cat = re.compile(test)
    
    test_ts = '|'.join(map(re.escape, TS_structs))
    regex_ts = re.compile(test_ts)
    
    matches_sub = regex.findall(row)
    matches_cat = regex_cat.findall(row)
    matches_ts = regex_ts.findall(row)
    print(matches_cat[0])
    print(matches_sub[0])
    print(matches_ts[0])
    #np1[i].append(matches[0])
    _tmp = np1[i].tolist()
    _tmp.insert(0,f"{matches_sub[0]}.{catalysts[matches_cat[0]]}")
    _tmp.append(matches_ts[0])
    _full.append(_tmp)
    
df2 = pd.DataFrame(_full)
print(df2)
sorted_df = df2.sort_values(by=0)
print(sorted_df)
sorted_df.rename(columns={0: "name", 1:"blank1", 2:"blank2", 3:"old_name", 4:"disp1", 5:"disp2", 6:"TS_struct"}, inplace=True)
print(sorted_df)
pivoted_df = sorted_df.pivot(index='name', columns='TS_struct', values='disp1')
pivoted_df2 = sorted_df.pivot(index='name', columns='TS_struct', values='disp2')
# Rename the columns to 'TS_struct_disp'
#pivoted_df.columns = [f'{col}_disp' for col in pivoted_df.columns]
print(sorted_df)
df_pivoted = pd.concat([pivoted_df,pivoted_df2], axis=1)
#df_pivoted = df1.pivot_table(index=["SMILES_cat-Substrate"], columns=0, values=4, aggfunc='first').reset_index()
df_pivoted.to_csv("organized_dispersion_data.csv")
#print(dF_pivoted)